#ifndef UINT64_PACK_H
#define UINT64_PACK_H

#include "crypto_uint64.h"

extern void uint64_pack(unsigned char *,crypto_uint64);

#endif
