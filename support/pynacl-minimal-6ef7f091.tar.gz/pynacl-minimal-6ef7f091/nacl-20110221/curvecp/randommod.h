#ifndef RANDOMMOD_H
#define RANDOMMOD_H

extern long long randommod(long long);

#endif
