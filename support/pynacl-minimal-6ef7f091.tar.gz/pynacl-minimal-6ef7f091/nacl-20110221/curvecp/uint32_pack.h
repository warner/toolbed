#ifndef UINT32_PACK_H
#define UINT32_PACK_H

#include "crypto_uint32.h"

extern void uint32_pack(unsigned char *,crypto_uint32);

#endif
