#ifndef UINT64_UNPACK_H
#define UINT64_UNPACK_H

#include "crypto_uint64.h"

extern crypto_uint64 uint64_unpack(const unsigned char *);

#endif
