#ifndef UINT16_UNPACK_H
#define UINT16_UNPACK_H

#include "crypto_uint16.h"

extern crypto_uint16 uint16_unpack(const unsigned char *);

#endif
