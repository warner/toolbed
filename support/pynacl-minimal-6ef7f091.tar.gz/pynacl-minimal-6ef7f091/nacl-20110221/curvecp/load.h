#ifndef LOAD_H
#define LOAD_H

extern int load(const char *,void *,long long);

#endif
