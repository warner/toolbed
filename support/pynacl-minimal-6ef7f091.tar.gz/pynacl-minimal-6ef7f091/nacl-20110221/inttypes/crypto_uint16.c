#include "crypto_uint16.h"
#include "unsigned.h"
DOIT(16,crypto_uint16)
