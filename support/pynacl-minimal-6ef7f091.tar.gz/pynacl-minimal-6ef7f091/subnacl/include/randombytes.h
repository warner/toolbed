#ifndef randombytes_H
#define randombytes_H

extern void randombytes(unsigned char *,unsigned long long);
#endif
