#ifndef crypto_uint64_H
#define crypto_uint64_H

typedef unsigned int crypto_uint64;
#endif
